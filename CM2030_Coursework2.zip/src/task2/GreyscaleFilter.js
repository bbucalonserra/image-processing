/** Converts a colour image to greyscale. */
class GreyscaleFilter {
    /**
     * Greyscale copy using the luma weights (week 15).
     * @param {p5.Image} source - Colour frame.
     * @return {p5.Image} Greyscale copy.
     */
    static apply(source) {
        const w = source.width;
        const h = source.height;

        source.loadPixels();
        const output = createImage(w, h);
        output.loadPixels();

        for (let y = 0; y < h; y++) {
            for (let x = 0; x < w; x++) {
                const index = PixelUtilities.pixelIndex(x, y, w);
                const grey = PixelUtilities.luma(
                    source.pixels[index],
                    source.pixels[index + 1],
                    source.pixels[index + 2]
                );
                output.pixels[index] = grey;
                output.pixels[index + 1] = grey;
                output.pixels[index + 2] = grey;
                output.pixels[index + 3] = 255;
            }
        }

        output.updatePixels();
        return output;
    }
}
